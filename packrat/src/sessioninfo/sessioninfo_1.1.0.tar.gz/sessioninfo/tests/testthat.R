library(testthat)
library(sessioninfo)

test_check("sessioninfo")

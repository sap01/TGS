context("bad")

test_that("good", {
  expect_true(TRUE)
})
